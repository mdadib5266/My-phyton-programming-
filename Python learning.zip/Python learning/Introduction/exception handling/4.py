#check password strength 1234
def check_password(password):
    if len(password) <8:
        raise Exception("Error: Password must be >=8 charracters")
    print('Password is strong')

try:
    password = input('enter a password = ')
    check_password(password)
except Exception as e:
    print(e)