try:
    num = int(input('enter a number :'))
    result = 10/num 
    print(f'result: {result}')

except ZeroDivisionError:
    print('You cannot devide with zero')

except ValueError:
    print('You cannot devide with string')
''' so we have write our main code under try: and problems or exceptions under except error:

format -
try:
    main_code

except error:
    message

except error:
    message
'''