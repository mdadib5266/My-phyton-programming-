try:
    file = open(r"C:\Users\Pedp4WPBX4125BLF1024\Documents\Python\exception handling\errors.txt",'r')
    content = file.read()
    print(content)

except FileNotFoundError:
    print('File not found')

finally:
    file.close()
    print('file operation completed')