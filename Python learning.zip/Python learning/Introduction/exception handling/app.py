#what are errors?
if 1==1 #this is syntex error
    print ('ok')

print(2/0)# its a compile time error. nothing wrong with the syntex but we cannot devide anything with error

a = int(input('number1 = '))''' see this , there is nothing wrong here but i put * instead of +.'''
b = int(input('number2 = '))
print('Total ')
print(a*b, 'sum')