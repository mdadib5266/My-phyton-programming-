"""
1 Operators are the functions used to perform mathematical and logical operations on values/variables
2 There are symbols of them 
3 Here values are called operends
4 Mathematical operators '+,-,*,/,**,//'
5 5 + 10 = 15 '5' and '10' are operends
6 operations are operated by BODMAS/PEMDAS
  B = brackets, O = ,D = divition, M = Multiplication ,A = Addition , S = subtraction
  P = Parenthesis(()), E = Exponent(**), M = Multiplication(*), D = Divition(/)
  Divition, multiplication and modulus are to be considered as 3rd priority
"""
x = 10
y = 5
print(x+y)