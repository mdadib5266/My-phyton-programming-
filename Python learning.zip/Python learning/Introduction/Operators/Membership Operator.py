"""
  Its used to check whether a value exists in a sequence or not
  It returns— True/ False
  veriables— 
  in 
  not in
"""
vegitables = ['Karela','Alu','Tamatar']
print('Alu' in vegitables) # python is case sensitive whether it for variables or strings
  #print(Tamatar in vegitables)
print('Vendi' in vegitables)
print('Tamatar' not in vegitables)
a = 1,2,3,4,5 
print(1 in a)
'''
a = 12345
print( 1 in a)
It gives an error as its not ittrable because 1 isnt a seperate value in 12345. 12345 is a single number
'''