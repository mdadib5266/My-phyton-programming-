"""
  Arithmetic Operator — To perform methematical Operator
  Comparision Operator — To comapre values
  Logical Operator — Can be comined multiple operators and compare values
  Assignment Operator — To assign values
  Idemtity Operator — To compare object memory location
  Membership Operator — To know ,does the value exist in sequences
"""
