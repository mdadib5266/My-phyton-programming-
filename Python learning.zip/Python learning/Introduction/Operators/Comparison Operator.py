"""
  Its used to compare
  It will give you output — True/False
  There are six comparison operators
    == — is it equal
    != — is it not equal
    < — is it less than that
    > — is it greater than that
    <= — is it less than or equal
    >= — is it greater than equal
"""
x = 10
y = 5

print(x == y)
print(x != y)
print(x > y)
print(x < y)
print(x >= y)
print(x <= y)