result = 10 + 5 * 2 # PEMDAS/ BODMAS
print(result)
"""
  or can be written as print(10 + 5 * 2)
"""