"""
  = — to assingn any value
  += — to add any value to the variable
  -= — to substruct any value from the variable
  *= — to multiply the variable by RHS value to the left hand side variable/operend
"""

x = 10
print(x)
x += 10 
print(x)
#x = x + 10, dont use
x -= 10
print(x)
x *= 10
print(x)