"""
  There are seven types of arithmetic operators— 
  Addition, 
  Subtraction, 
  Multiplication, 
  Divition,
  Floor divition, 
  Modulous — remainder
  Exponential — power
"""
x = 10
y = 20
print(x+y)
print(x-y)
print(x*y)
print(x/y)
print(x//y)#floor divition
# floor divition will omite fractional value
print(x%y)#modulous operator
print(x**y)#exponential operator. Make sure you dont use space between the * symboles