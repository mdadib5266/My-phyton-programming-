"""
  Identity operator is used to compare the "memory loaction" of two objects
  Operators are—
  is — is memory location or object same
  is not — is memory local or object not same
  Identity operator retiens— True/False [ as they comapare ]
  
  I cannot commwnt into a function
  #Question: Whats difference between 'is' and '=='? 
"""
a = [ 1, 2, 3]
b = a
c = [ 1, 2, 3]
print(b is a)
print(a is c)