class student:
  def __init__(self,name, age, grade):
    self.name = name
    self.age = age
    self.grade = grade

#creating objects
student1 = student('rakesh',100,'A+')
student2 = student('kalpesh',50,'B+')

print(student1.name, student1.age,student1.grade)
print(student2.name, student2.age,student2.grade)
"""
#there are three types of constructors 
1 default constructors— we dont pass any parameters
2 parameterized constructors — we define parameters in it like (self, name, age)
3 contructor with default values — there a default value if i dont pass any and it will be changed if i pass any
"""