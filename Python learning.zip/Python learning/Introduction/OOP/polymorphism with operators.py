print(10+5)
print('hello'+'world')
print([1,2]+[3,4])
'''in polymorphism ,we can use any method or operators for different types of reasons like the plas sign'''