"""
#contructor method and it defined like this
__init__()
#finstructor is used to initialize any object as soon as the object is created
"""
class car:
  def set_details(self,brand,color):
    self.brand = brand
    self.color = color

#creating objects
car1 = car()
car1.set_details('Tesla','Red')

print(car1.brand)
print(car1.color)