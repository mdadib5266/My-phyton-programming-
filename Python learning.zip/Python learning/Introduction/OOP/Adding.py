class Car:
  def set_details(self,brand,color):
    self.brand = brand
    self.color = color
  def show_details(self):
      print(f'This is a {self.color} {self.brand}')
#main blue print
#this set of code is used as a main blue print which can be used for different type of objects
car1 = Car()#these will act as switches to activate the class
car2 = Car()#these will act like a switch to activate the class 
car1.set_details('Tasla','Red')

#car2 = Car()
car2.set_details('BMW','Blue')

car1.show_details()
car2.show_details()