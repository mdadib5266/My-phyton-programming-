class car:
  def __init__(self,brand,color):
    self.brand = brand
    self.color = color

car1 = car('Tesla','Red')#values are automatically set 
#we dont have to call the method now like car1.set_details('Tesla','Red'). we can dorectly write it into car1 = car('Tesla','Red')
print(car1.brand,car1.color)
'''
syntex:
class class_name:
  def __init__(self,parameter1,parameter2):
    self.property1 = parameter1
    self.property2 = parameter2

__init__() — constructor
self.property:
'''