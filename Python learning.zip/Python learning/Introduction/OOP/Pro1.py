class car:
  def set_details(self,brand,color):#self defines the object.
  #always use self to store properties inside an object.
  # without self we cannot store propertiee inside an object . it will give error
    self.brand = brand
    self.color = color
  def show_details(self):
    print(f'This car is a {self.color} {self.brand}')

car1 = car()
car1.set_details('Tesla','Red')

car2 = car()
car2.set_details('BMW','Blue')

car1.show_details()
car2.show_details()