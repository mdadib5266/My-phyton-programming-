class car():
  #method 
  def start(self):#these works exactly as a normal method and we have to call th like variable.method()
    print('Car is starting.....')
  def stop(self):
    print('CAR IS STOPING....')
Car1 = car()
Car2 = car()

Car1.start()
Car1.stop()

Car2.start()
Car2.stop()
