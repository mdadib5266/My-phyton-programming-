class student :
  def set_details(name,age):
    name = name
    age = age

student1 = student()
student1.set_details('udit',95)
print(student1.name)