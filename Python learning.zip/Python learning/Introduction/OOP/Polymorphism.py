"""
one name ,many forms 
run 
person runs fast 
car runs on petrol
computer program runs smoothly

1 word = run
"""

print(len("python"))
print(len((1,2,3)))
print(len({"a":1,"b":2,"c":3}))

