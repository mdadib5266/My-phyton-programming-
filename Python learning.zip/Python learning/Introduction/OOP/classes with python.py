#polymorphism with classes method overriding
class Bird():
    def sound(self):
        print("Birds make sound")

class Crow(Bird):
    def sound(self):
        print('Crows say "Caw Caw"')

class Parrot(Bird):
    def sound(self):
       # return super().sound()
       print('Parrot sounds,squawk')

bird1 = Crow()
bird2 = Parrot()

bird1.sound()
bird2.sound()
#Crow.sound().here i have to call the variabe Crow containing it into another variable like line 15. 
""" polymorphism means the class will be th same but it will act differently in different situtions """