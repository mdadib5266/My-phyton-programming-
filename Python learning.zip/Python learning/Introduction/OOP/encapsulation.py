''' encapsulation means hiding any internal details of an object and it will prevent direct access
thus encapsulation hides data which prevents the data from being modified
we can give a controlled access two methods getter and setter
'''
class bankaccount:
    def __init__(self,account_number,balance):
        self.account_number = account_number
        self.__balance = balance #when we put double underscore after self. and before the variable it becomes private variable.
    
    def deposit(self,amount):
        self.__balance += amount
        print(f'Deposited {amount}.New balance {self.__balance}')
    
    def get_balance(self):
        return self.__balance #controlled access

account = bankaccount('12345',5000)

account.deposit(2000)
print(account.get_balance)
