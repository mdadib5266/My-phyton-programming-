class student:
  def set_details(self,name,marks):
    self.name = name
    self.marks = marks

student1 = student()
student1.set_details('udit',95)
print(student1.name, student1.marks)