class charracter:
  def __init__(self,name,health,attack,blood):
    self.name = name
    self.health = health
    self.attack = attack
    self.blood = blood
#if we define a function under a class , we call it a method .
  def attack_enemy(self):
    print(f'{self.name} attacks with power {self.attack}{self.blood}')

warrior = charracter('Thor',100,50,' red')
mage = charracter('Gandalf',80,70,' black')
archer = charracter('Archer',80,90,' white')

warrior.attack_enemy()
mage.attack_enemy()
archer.attack_enemy()
"""
1- classes and objects
2- inheritance
3- encapslation
4- abruption
5- polymorphism
"""