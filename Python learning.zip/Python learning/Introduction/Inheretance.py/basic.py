class Animal:
    def speak(self):
        print('Animals make sounds')

class Dog(Animal):
    def bark(self):
        print('Dogs bark')
''' Animal class has speak method but Dog class doesnt . so we cant use that other method which isnt present 
in the second Dog method and in order to use that in th Dog method we have to put the animal method inside the Dog method. 
other words we have to use inheretance
and if i create a new method under the Dog , it will override the existing method
'''
dog = Dog()
dog.speak()
dog.bark()