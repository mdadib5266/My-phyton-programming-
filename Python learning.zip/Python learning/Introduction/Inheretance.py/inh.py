parent class
   def p1 p2(self):
        

child class
   def p3 p4 p2
#inheretance inherete properties from the parent class 
# like the example im creating a property under class like the parent class . here i dont have to weite the property twice i just copy and paste it.
