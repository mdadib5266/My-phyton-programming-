''' data abstruction hides complex details from the user
abstruct is a class
 '''
from abc import ABC,abstractmethod

class Vehicle(ABC):
    @abstractmethod
    def start(self):
        pass # NO implementation

class Car(Vehicle):
    def start(self):
        print('Car starts with a key')

class Bike(Vehicle):
    def start(self):
        print('Bike starts with a button')

car = Car()
bike = Bike()

car.start()
bike.start()
'''
abstract class hides unnecessery details 
abstract classes cant be instanciated , it only works as a blueprint
child classes must define abstruct classes
'''