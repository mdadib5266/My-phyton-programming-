a = [ 1,2,3]
b = [4,5,6,a,7,8,9]
print(b)#nestes list