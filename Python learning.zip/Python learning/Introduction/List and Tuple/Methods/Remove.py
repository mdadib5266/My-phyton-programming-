a = [1,2,3]
a.remove(2)#Remove method will earse the number or element i passed into the first bracket
# i can enter only one element not list or multiple elements
print(a)