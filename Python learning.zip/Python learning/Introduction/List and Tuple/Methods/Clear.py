a = [1,2,3]
a.clear()#it will clear all the elements of the list or tuple and cannot take multiple elements or a list
print(a)