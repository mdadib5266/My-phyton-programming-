a = [1,2,3,4,5,6,7]
index = a.index(5)#it can work with only one element 
#format— variable.index(single element)
# index method returns the index number of any element
print(index)
