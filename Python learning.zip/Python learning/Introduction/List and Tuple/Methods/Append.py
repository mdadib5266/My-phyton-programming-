a = [1,2,3]
a.append([4,5])#it will add the object at last of the list
#we can pass any kind of variabe here
#Append will add a list /tuple and like that . not mutiple numbers or strings saperated by comma 
# Append will insert the list /tuple entirely with the third bracket not the elements but one element can be added directly
#Elements are added by extend method
print(a)