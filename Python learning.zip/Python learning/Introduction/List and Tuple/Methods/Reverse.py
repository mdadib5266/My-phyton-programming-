a = "python"
print(a[::-1])# it will reverse every single word
a = [2,1,3]
a.reverse()#reverse method will reverse every sigle element according to as it were
print(a)