a = [1,2,3]#insert isnt updating
#insert allows us to insert any element or variable into our determined position according to the index number
a.insert(0,'hi coders')#format— variable.insert(index,data i wanna input)
print(a)# insert will not delete anyting .it will only insert any veriable or list at our determined position by index number and the rest will be the same