a = [1,2,3]
b = [4,5,6]
print(f'concetenated{a+b}')
a.extend(b)# it will extend the a list with the b list or variable(its elements only not the entire list or tuple)
print(f'extended{a}')# basically extention = concetenation