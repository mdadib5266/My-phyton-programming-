a = [1,2,3]
popped = a.pop(1)#it willnreturn the removed number
#pop method will work with only one element 
print(popped)
print(a)