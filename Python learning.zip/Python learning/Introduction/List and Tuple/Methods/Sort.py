a = [90,50,120,-1,-5,-10,4,5]
sorted_a = a.sort()
print(a)#it will sort the numbers in an accending way by difault