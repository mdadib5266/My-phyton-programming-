a = [1,2,3,"python","java",True,1,1,1,2,3]
counter = a.count(1)#count method will count how many times the element is present there
print(counter)# the output is 5 even though 1 is present 4 times there . cuz Ture == 1!
boolean = a.count(True)
print(boolean)#output — 5 cuz True == 1