lst = [1,2,3,4,5]
print(f'Before list {lst}')
lst[0] = 'hello'#this will interchange the 'hello' with the first element of lst list or variable
print(f'After list {lst}') 

'''lst = lst[0:3]
print(f'Afer slicing {lst}')
lst[0:3] = 10,20,30'''

print(f'After interchange {lst}')