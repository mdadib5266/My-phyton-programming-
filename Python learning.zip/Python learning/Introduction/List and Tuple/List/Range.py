#number = range(,,)
'''
start — 1
stop — 100
step — 1
it can only be be used in terms of integersamd numbers
'''
number = range(1,100,1)# its exclusive
print(list(number))
number = range(1,101,1)
print(list(number))# it should be cknverted