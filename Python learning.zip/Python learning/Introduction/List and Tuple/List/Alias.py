lst_1 = [1,2,3]
lst_2 = lst_1# it will point at the same variable lst_1, lst_2 will not be a seperate variable # its aliasing
print(lst_2)
lst_2[0] = 100# it will change both of the variables as as lst_1 = lst_2
print(lst_1,lst_2)

