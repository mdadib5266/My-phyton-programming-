lst_2 = [6,7,8,9,10]
check = int(input('enter a number —'))
if check not in lst_2:# it will show that its not in the lst_2
  print('Yes not found')
else: 
  print('found')