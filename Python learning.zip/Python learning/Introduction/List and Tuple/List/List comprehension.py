"""
[exoresion for item in iterable — we cam add if condition if we want]
exoression — like x*2
item — element
iterable — range(1,11)
condition optional
"""
squre = []
for i in range(1,11):
  squre.append(i ** 2)
print(squre)
# list comprehension
squares = [i ** 2 for i in range(1,11)]#format—[ exoression for variable in list/range if condition ]
print(squares)
even_numbers = [i ** 2 for i in range(1,11) if i%2 == 0]
print(even_numbers)