a = [1,2,3,-10,-5,100,200,0]
print(min(a))
print(max(a))