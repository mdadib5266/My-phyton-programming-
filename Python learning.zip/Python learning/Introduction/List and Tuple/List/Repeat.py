str = "hi"
print(str * 3)# it will repeat the basestring
lst = [1,2,3,'z',True]
result = lst * 3
print(result)# it will repeat same list as much as i want but it will reamin one list