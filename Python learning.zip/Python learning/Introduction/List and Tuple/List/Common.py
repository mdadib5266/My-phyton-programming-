a = [1,2,3]
b = [3,5,6]
#set function
s1 = set(a)
s2 = set(b)

s3 = s1.intersection(s2)# it will find the common element
print(list(s3))