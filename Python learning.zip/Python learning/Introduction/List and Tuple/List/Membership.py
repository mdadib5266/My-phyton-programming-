"""
in - True/False — if the element exisr or not
not in - opposite — it will alter the 
"""
lst_1 = [1,2,3,4,5]
check = int(input('enter a number to ckeck'))
if check in lst_1:
  print('Found')
else:
  print('not found')