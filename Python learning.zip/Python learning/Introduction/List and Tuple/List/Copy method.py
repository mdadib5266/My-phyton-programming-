list_1 = [1,2,3]
list_2 = list_1.copy()#this copy method will copy the list_1 and store it into list_2
# it will act like an independant variable 
list_2[0] = 100
print(list_1, list_2)
