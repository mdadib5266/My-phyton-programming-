a = [1,2,3]
a_copy = a.copy()
print( f'Original{a}/n')#it will copy rhe original variable into a_copy and act as a free variable and whatever change i make in it ,it will not affect the original variable . normally it would.