#1 squire brackets 
my_list = [1,2,3,10,56,"hello",True]
print(my_list)
#2 using list constructor
my_list = list((1,2,3,10,56,"hello",True))
print(my_list)
#3 using range functio