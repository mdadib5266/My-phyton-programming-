lst_1 = [1,2,3,4,5]
lst_2 = [6,7,8,9,10]
result = lst_1+lst_2
print(result)
# it will simply add add the first lists elements with the second lists elements