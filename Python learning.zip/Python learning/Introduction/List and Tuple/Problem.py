name = "ramesh"
age = 25
marks = 75.55
# taking multiple types of data under different types of variable is hard .so wr need a solution