#problem
a = 10
b = 20
print(a+b)
# functions are a block of codes which can be used again and again
#1 reusability
#2 modularity
#3 code diplication none
#4 scoping
#5 may be slow
#6 complexiety of code 