a = (1,2,3,4,5,6)
print(a[0])
"""a[0] = 100
print(a)#tuples arent iterable
#we will use tuple only when we wont have to change the variable
"""
print(a[0:3:1])