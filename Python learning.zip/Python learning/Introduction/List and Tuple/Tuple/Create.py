a = 10,20,30
print(type(a))
b = (10,20,30)
print(type(b))
c = ()
print(c)
""" we can use 
len()
min/max()
count()
index()
sort()
"""