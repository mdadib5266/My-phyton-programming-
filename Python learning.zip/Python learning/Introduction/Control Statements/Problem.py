#Area of circle
pie = 3.1416
radius = float(input('Enter radius = '))
#To convert any value into another type data,we have to follow this format 'datatype(the valuse i want to convert)'
#strings cant be converted into float or integer
area_of_circle = pie * radius * radius
print(f'Area of circle :{area_of_circle}')