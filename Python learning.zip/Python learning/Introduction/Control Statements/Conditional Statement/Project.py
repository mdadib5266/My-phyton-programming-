num_1 = float(input('Enter number 1 ='))
num_2 = float(input('Enter number 2 ='))

choice = input('Enter your choice: + - * / % // **')
if choice == '+':
  print(num_1 + num_2)
elif choice == "-":#Thus, ""s can also be used
  print(num_1 - num_2)
elif choice == '*':
  print(num_1 * num_2)
elif choice == '/':
  print(num_1 / num_2)
elif choice == '//':
  print(num_1 // num_2)
elif choice == '%':
  print(num_1 % num_2)
elif choice == '**':
  print(num_1**num_2)
else:
  print('Error occoured')
