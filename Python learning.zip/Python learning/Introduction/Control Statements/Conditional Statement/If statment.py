""" 
Firmat
  if condition:
    statments
statmentsmust after a tap space
"""
age = int(input('Enter your age:'))
if (age >= 18):
  print('You can vote!')
  if(1 == 1):
    print('Equal to')
print('hi') # Its independant because its not written after one tap under if