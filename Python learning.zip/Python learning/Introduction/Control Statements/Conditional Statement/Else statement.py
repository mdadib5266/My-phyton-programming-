age = int(input('Enter your age ='))
if age >= 18 and age  <= 100:#True
  print(' You can vote!')
elif age <= 0: 
  print('Invalid age')
elif age >= 101:
  print('Greater than 100')
elif age >= 18: 
  print('Less than <18')
else:
#else acnt be written before if 
#else will only be executed when if is false
  print('Error occured')
  