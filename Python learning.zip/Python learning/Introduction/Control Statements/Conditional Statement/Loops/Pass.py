"""
  # pass is used to as a dummy place holder which doesnt do anyting but allows the program run.
"""
for num in range(1,10):
  if num == 5:
    pass
    # we cam change it over time to continue or break
  print(num)