a = [1,2,3,4,5]
b = ['a','b','c']
for i in a:
  """
  #For doesnt work here as like as c. In c we can pass condition through for but here it isnt possible. its done by while.
  # i is variable
  # a sequence
  
  i = 1
  i = 2
  i = 3
  .....
  i = 5
  
  i 'a'
  ...
  """
  print(i)
for i in b:
  print(i)