start = int(input('Enter start ='))
stop = int(input('Enter stop ='))
skip = int(input('number you wnat to skip ='))
if skip >= start and skip < stop:
  if start < stop :
    for i in range(start,stop):
      if i == skip:
         continue
      print(i)
  else:
    print('Invalid range')
else:
  print('Invalid range')
  
'''elif start >= stop:
    print('Invalid range') 
    break
  elif start == stop == skip:
    print('Invalid range')
    break
  elif i == skip:
    continue
  print(i)
  '''