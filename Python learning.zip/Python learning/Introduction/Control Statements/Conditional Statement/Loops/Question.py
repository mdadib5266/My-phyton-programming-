"""
  Showing even numbers from 1 to 10
  even numbers
  2,4,6,8,10
  odds
  1,3,5 7,9
  
  a number will be even if its modulus/remainder is 0 when devided by 2.
"""
for num in range(1,11):
  if num%2 == 0:
    print('even',num)
  else:
    print('odd',num)