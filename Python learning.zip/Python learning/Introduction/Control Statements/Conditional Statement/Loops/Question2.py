start = int(input('Enter start ='))
stop = int(input('Enter stop ='))
skip = int(input('Enter the number you want to skip '))
'''
if start > stop:
  print('Invalid range')
else:
'''
for i in range(start,stop):
    if i == skip:
      continue
    print(i)