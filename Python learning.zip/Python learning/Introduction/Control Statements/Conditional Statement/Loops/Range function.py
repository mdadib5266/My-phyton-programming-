"""
Syntex— range(start, stop, sstep
start — 1
stop — 100
step — 1
# In range function , stop is always exclusive meaning the last number generated will be 1 less than the number we inputed as stop. 
# Even if i dont pass any step, it will take 1 as step value by difault.
# We can write range as range(start,stop)
"""
range = list(range(1, 101, 1))
print(range)
print(tuple(range))