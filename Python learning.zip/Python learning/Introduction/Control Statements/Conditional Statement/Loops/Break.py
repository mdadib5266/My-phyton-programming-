"""
  #break statment is used to break a statment immediately when a condition is met.
  #break will not continue the flow after breaking
"""
for num in range(1,10,1):
  if num == 5:
    break
  print(num)
