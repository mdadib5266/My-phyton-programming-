start = int(input("Enter start = "))
stop  = int(input("Enter stop  = "))
skip  = int(input("Number you want to skip = "))

# 1) Validate the range
if start >= stop:
    print("Invalid range")

# 2) Validate the skip value
elif skip < start or skip >= stop:
    print("Invalid number")

# 3) All clear — iterate and skip the one value
else:
    for i in range(start, stop):
        if i == skip:
            continue
        print(i)