i = 1
while i <= 5:# it will check the condition every time
  """
  1st iteration
  i = 1 <= 5 True
  2nd iteration
  i = 2
  i = 2, i<=5 = True
  .....
  5th iteration 
  i = 5, i<=5 True
  6th iteration
  i = 6, i<=5 False
  """
  print(i)
  i += 1
#While loop will continue the loop as its organized