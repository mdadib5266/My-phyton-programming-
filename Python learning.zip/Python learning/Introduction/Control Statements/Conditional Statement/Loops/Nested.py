for i in range(1,3):
  """
  #The second loop wont quit from the first loop as long as the condition passed in second loop remains True.
  i = 1
  j = 3
    i = 1
    j = 4
      i = 1
      j = 5
        i = 1
        j = 6 #The condition breaks and it will go out of the second for loop.
  i = 2
  j = 3
    i = 2
    j = 3
      ...
  """
  for j in range(3,6):
    print(f'{i},{j}')