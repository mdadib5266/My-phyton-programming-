while True:
  print('Hi')