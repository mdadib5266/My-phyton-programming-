"""
  #continue statment is used to skip the current iteration and move to the next one.
"""
for num in range(1,5):
  if num == 3:
    continue
  print(num)# it skipped 3