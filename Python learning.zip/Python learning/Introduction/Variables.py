name = "Adib"
age = 100
height = 6.3
print(name,age,height)
#1name = " Adib"
#%$name = "Adib"
_name = " Adib"
n1ame = 'Me'
print(_name,n1ame)
#wrong variables 1nmae, %$name ,na me
#only under score can be used
# white space isnt allowed in the middle of a variable 