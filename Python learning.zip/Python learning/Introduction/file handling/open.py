'''
open("file name","mode")
# we have to pass file name/we can pass location as well
#modes are like read , write etc. 
'''
file = open(r'C:\Users\Pedp4WPBX4125BLF1024\Desktop','w')
#we have to write open function in order to read,write etc.
#this read mode will only open and read the file
#read mode will not create a new file if the path stared doesnt exist,it will show error.
#this write method will not overwrite existing data
content = file.write('hi')
print(content)
file.close()