with open(r'C:\Users\Pedp4WPBX4125BLF1024\Documents\Python\file handling\data.txt','w') as file:
    content = input('enter content to write = ')
    file.write(content)
    print('saved!')