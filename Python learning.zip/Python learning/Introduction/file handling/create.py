import os
file_name = input("enter file name:")
if os.path.exists(r'C:\Users\Pedp4WPBX4125BLF1024\Documents\Python\file handling\ file_name'):
    print("exists")
else:
    print(f"doesnt exist,Do you want to create {file_name}?")
    answer = input("yes/no")
    if answer == 'yes':
        print('yes')
