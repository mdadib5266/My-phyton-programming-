with open(r'C:\Users\Pedp4WPBX4125BLF1024\Documents\Python\file handling\data1.txt','a') as file:
    content = input('enter data to append = ')
    file.write(content)
    print('appended data')