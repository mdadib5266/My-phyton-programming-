#single line comment
'''
this is aulti line 
comment
'''
""" 
this
is a multi line conmment
"""
print('Hi')
