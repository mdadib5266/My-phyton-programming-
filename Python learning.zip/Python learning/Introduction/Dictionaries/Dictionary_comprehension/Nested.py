programming_language = {
  "python":{"name":"python","use_case":['ai,ml,webdev,ds']},"java":{"name":"java","use_case":['app dev']}
}# here 'pyrhon' is another dictionary
#we create the aecond dictionary under the first one using colon after the key not equal sign.
#nested dictionary
print(programming_language)