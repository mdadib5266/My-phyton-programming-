profile = {
  'name':'raju','age':100,'salary':25000.00
}
for k in profile.keys():
  print(k)
for k in profile.values():#to access all the values without keys.
  print(k)# for loop accesses only the keys in a dictionary not the values as well.
for k in profile.items():
  print(k)