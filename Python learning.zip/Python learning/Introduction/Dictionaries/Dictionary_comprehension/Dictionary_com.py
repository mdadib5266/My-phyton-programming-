squares = {
  x:x*x for x in range (1,6)#its exclusive
}
print(squares)
print(type(squares))