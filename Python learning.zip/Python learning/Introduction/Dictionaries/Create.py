my_dict = {
  #if i dont pass anything then it will be my empty dictionary
  #dictionaries are made un curlie brackets
  #format — "key":"value","key":"value"....
  "Name":"Adib","Age":100,"Marks":50.55,100:"abc"#we can use integer as key or anything
  ,"marks":[1,2,3,4],"marks":100# we can store lists, tuples,array etc as values
  # key should be unique otherwise it will return the overided vale of the repeatedly presented key
  #keys and values can be stored under double and single coute
}
print(my_dict)