profile = {
  'name':'raju','age':100,'salary':25000.00
}
list_items = profile.items()
print(list_items)
print(list(list_items))# items method will return the dictionery values as tuple individually