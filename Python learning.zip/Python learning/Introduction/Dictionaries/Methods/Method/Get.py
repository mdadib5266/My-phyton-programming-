profile = {
  'name':'raju','age':100,'salary':25000.00
}
#dictionary_name.medthod('key')
#we will use get method when we will retreve any value of a key
age = profile.get('age','found')#we can pass something as an statment which will be showed if the value isnt there
print(age)
age = profile.get('age_2','not found')
print(age)#it will return none meaning nithing and the key want fount