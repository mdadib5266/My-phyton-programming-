profile = {
  'name':'raju','age':100,'salary':25000.00
}
popped_i = profile.popitem()# it will remove the last item of the dictionary
print(popped_i)
print(profile)