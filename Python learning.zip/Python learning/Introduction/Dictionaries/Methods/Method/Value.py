profile = {
  'name':'raju','age':100,'salary':25000.00
}
values = profile.values()
print(values)
print(list(values))