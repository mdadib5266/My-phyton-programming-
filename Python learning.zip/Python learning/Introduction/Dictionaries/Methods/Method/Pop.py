profile = {
  'name':'raju','age':100,'salary':25000.00
}

popped = profile.pop('age')#pop method will return the removed value and show the value of the variable in the mathod .here 'popped'

print(popped)
print(profile)
popped = profile.pop('key','not found')
'''print(popped,'not found')'''# its wrong.we will have to write the message 'not found 'in within the first brackets of the method .
print(popped)#if the key isnt found, the program will show the second message .
# but if it find the value ,it wont show the second message