profile = {
  'name':'raju','age':100,'salary':25000
}
keys = profile.keys()
print(keys)
print(type(keys))
print(list(keys))