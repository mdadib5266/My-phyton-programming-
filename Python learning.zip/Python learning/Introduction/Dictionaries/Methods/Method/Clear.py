profile = {
  'name':'raju','age':100,'salary':25000.00
}
print(profile)
print(list(profile))#it will return only the values
cleared = profile.clear()
print(profile)