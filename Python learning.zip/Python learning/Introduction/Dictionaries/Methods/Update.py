my_dict = {
  'name':'python','version':3.9
}
print(my_dict)

my_dict['version'] = 4#as like as add method
print(my_dict)
my_dict['updated_version'] = 5#if the key isnt present in the dictionary it will add a new one
print(my_dict)