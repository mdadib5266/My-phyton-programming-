my_dict = {
  'name':'python','version':3.9,'Use_case':['Ai','ML','DS','WD']
}
print(my_dict)
del my_dict['version']#format — method_name variable['key'] 
#remember theres no dot after the mathod name
print(my_dict)