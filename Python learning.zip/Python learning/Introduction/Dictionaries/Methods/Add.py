my_dict = {
  'Fruites':['Banana','Apple','Orange'],'Category':'Fruit'
}
print(my_dict)

my_dict['Price'] = 100
#format['key'] = value
#my_dict.add('Price':100) — error
print(my_dict)