# we can store data in pairs in dictionaries 
#format — key:value# key is the container and the value is the containee
# we can store multiple apinrs in a single variable.
#pair — apple:fruit
# comma is used to saperate pairs
# unordered but after python python 7 it became unordered
# dictioneries are dymamic and mutable 
# and every mutable element has method 
# curlie brackets are used to make dictioneries
