#lambda are called anynomous functions as well .
#we dont name it 
# easy syntex
# we can send one syntex at a time 
#format — lambda argument:expression condition
add_Ten = lambda x:x+10
print(add_Ten(5))
add_ten = lambda x:for i in range(x)
print(add_ten())# not yet complete