def greet():
  '''displaying a hi message'''#docstrings
  print('Hi')
'''
#function creation
def calling_name():
  statment
calling_name()
'''
greet()