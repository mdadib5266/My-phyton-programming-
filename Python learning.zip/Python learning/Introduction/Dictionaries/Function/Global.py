def msg():
  print("inside the function",choice)
choice = "i love coding"#this choise variable can be used inside and outside of the program cuz its global variable
msg()
print(choice)