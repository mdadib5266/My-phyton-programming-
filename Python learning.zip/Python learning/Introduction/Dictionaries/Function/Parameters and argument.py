def greet(name):#name— parameter
# the parameter will work only when you give its value meaning its argument.
  print('Hi',name)
greet("adib")#Adib — argument
greet("sagar")
greet("raju")
'''
parameters are variables that act like place holders for the values which are passed when calling
'''
"""
arguments— the value passed as value of the parameters
"""
'''
there are three types of arguments
  positional argument 
  keyword
  default
'''