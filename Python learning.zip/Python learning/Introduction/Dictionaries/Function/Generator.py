# generators generate value on demand. it doesnt consume much memory.
# if i want access 1-10 then for loop will access 1-10 at once but generators access values one by one like you generate a range one to ten but i need one number
#yeld kwyword
def count_down(num):
  while num > 0 :
    yield num#yield values one at a time 
    num -= 1 
#using the generator 
for number in count_down(5):
  print(number)
"""
decorators 
  decorators are used to add extra functionality.
generators
  generators are used to generate values over time . it doesnt access all the values at once
  """