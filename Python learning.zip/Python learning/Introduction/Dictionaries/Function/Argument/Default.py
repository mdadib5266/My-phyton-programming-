def greet(name='raju',city='mumbai'):#this is default argument where some arguments are preassigned . if the user doesnt pass anyting on his own it will take those values by difault but if he does , it wont take the default ones.
  print(f'Welcome {name} to the {city}')
greet()
greet("aman",'feni')
greet(name="ayan",city="chittagong")