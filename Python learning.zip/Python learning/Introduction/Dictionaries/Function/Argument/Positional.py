def greet(name,city):
  print(f'Welcome {name} to the {city}')
greet('raju','mumbai')
#greet('mumbai',"raju")
# positional arguments are those arguments which are assigned as per their position 
# here i have to maintain the sequence of name and city for the argument 