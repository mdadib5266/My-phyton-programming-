def greet(name,city):
  print(f'Welcome {name} to the {city}')
greet(city='mumbai',name='raju')
# this is keyword argument 
# we assign arguments writing equal sign after the keywords and we dont have ro follow right chronology