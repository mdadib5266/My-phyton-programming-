def sum(a,b):
  return a+b

a = 10
b = 20
result = sum(a,b)
print(result)