#return function is a function which is used to go back to a function
def get_full_name(first_name,last_name):
  '''returm the full name , in a neated format'''
  full_name = f'{first_name} {last_name}'
  return full_name
name = get_full_name('gopal','raju')# when we are calling any function , we will always have to store it in a veriable
# we will have to use a different variable only when we use return under a function.
print(name)
def get_full_name(first_name,last_name):
  full_name = f'{first_name} {last_name}'
  return full_name
name = get_full_name('gopal','raju')
print(name)
def get_full_name(first_name,last_name):
  full_name = f'{first_name} {last_name}'
  print(full_name)
name = get_full_name('gopal','raju')
print(name)
'''
 function naming- clear
 length of functions
 avoid global variables
  local variables — these are used under a function and cant be used elsewhere
    accesable in the function
  global variable — these variables can be used anywhere in a program
    accessable throughout the program
 '''