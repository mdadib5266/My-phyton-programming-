"""
burger — function
extra — extra future

decorators add a new function under
function without changing the main code 
"""
def my_decorator(func):
  def wrapper():
    print("somethings happening before the function is called")
    func()
    print(" Something is happening after the function is called")
  return wrapper  
@my_decorator#thats how we call decorator.it should be called before not after 
def say_hello():
  print("hello")
say_hello()