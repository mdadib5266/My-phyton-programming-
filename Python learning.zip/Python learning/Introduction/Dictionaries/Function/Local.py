def msg():
  #local variable
  choice ="i love coding"
  print(choice)
msg()
print(choice)#choice variable isnt globally accessable