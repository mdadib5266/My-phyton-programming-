#number = 10
#print(number * 20)
number = '10'
print(number * 20)
# As 10 is a string , it will not be multiplied but it will be repeated 20 times.
print(number ** 20)# type error