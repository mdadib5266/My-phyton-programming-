text = "python"
print(text[0])
print(text[-1])
print(text[100])