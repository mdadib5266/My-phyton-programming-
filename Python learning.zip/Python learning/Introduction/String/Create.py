name = 'adib'
name_2 = "python"
name_3 = '''
this is muti line
string
'''
name_4 = """
this a multi line
string
"""
print( name, name_2, name_3,name_4)
'''
---------------------------
#3 characterstics
  # immutable — can be updated but cannor be changed.
  # When i write anything under tripple quote/tripple double quote, it becomes a comment but when i write anything under tropple qoute/double teipple quote but as a veriable, it becomes a muti line string.
  '''