# checking memberahip
'''
if i have a data base and i have to find if anything in the data base , wr use membership .
membership operators —
  in 
  not in 
it provides answers in boolean values
'''
text = "python is the king"
print("king" in text)
print("king" not in text)
print("java" in text)
print("java" not in text)