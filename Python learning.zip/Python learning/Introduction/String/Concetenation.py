a = 10
b = 20
print(a+b)
'''
we can add two strings together which is called concetenation.
but we cannot add integers with string . it will give type error.
we can add string with string
'''
name = 'adib'
sur_name = 'shad'
print('Hi', name+sur_name)
