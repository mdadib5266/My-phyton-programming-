language = "python"
for i in language:
  print(i)# strings are iterable . so i can access all of the word one by one . Loop can be ooerated on them