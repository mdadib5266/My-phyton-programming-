str = 'python'
count = 0
for i in str:
  count += 1
print(count)