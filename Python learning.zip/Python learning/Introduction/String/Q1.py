passward = '123'
if len(passward) > 5:
  print('Long in successful')
else:
  print('Log in unsuccessful')
  