a = 'python'
print(a[0])
'''
#Positive indexing goes left to right from 0
#Negative indexing goes right to left from -1
'''
print(a[-1])