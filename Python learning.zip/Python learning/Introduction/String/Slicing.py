text = "python"
print(text[0],text[1],text[-1])
'''
#Slicing slice a peace of some words from a
indexed variable

#string[start:stop:step]
# its exclusive
start = 0
stop = 4 #the last number given will be excluded = 4
'''
text = "this is python the king of ai"
print(text[::-1])
print(text[::1])
#if i enter -1 then the full string will be reversed
#Interval 1 means one after another
#if i dont pass anything it will take full string