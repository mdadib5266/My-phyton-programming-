#length
str = 'python'
str1 = 'python is the king'
count = 0
print(len(str))
for i in str1:
  count += 1
print(count)
#print(len(str1))
#print(length(str)) wrong