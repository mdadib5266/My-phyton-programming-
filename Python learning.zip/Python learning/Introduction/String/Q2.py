email = "user@gmail.com"

if "@" in email:
  print('valid email')
else:
  print('invalid email')