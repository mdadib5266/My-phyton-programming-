str = "Python"

print(str.isdigit())
#is all the charracters of the variable is made of digits only or not