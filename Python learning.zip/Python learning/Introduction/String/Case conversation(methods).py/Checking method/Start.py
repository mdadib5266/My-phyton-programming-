str = "Python"
# membership defines whether the charracter is present there or not
#in start method we will define whether the string is starting with any perticuler charracter or not
#it will return a boolean value — True/False
print(str.startswith("P"))
print(str.startswith("p"))