str = "Python"
print(str.endswith("on"))
# endswith will check whether the string is ending with any perticular set of string or object
#python is case sensitive