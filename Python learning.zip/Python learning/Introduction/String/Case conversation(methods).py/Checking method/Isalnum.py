str = "Hello123"

print(str.isalnum())
# it will check whether the string is .ade by the mixture of charracters and numbers or not. it has not be the first or the lasr charracter is numeric or alphabetic
#format — variavle_name.isalnum()