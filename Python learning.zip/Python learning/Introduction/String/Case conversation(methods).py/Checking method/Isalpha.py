str = "Python"

print(str.isalpha())
#it will check whether the string is starting with a alphabetic charracter
#format — variable.isalpha()