text  = "Python programming"
print(text.replace("Phython","Java"))
#in case of replace method we have to write our syntex like variable.method_name(the object we want to remove , what we will plce in exchange) 