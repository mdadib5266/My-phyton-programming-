str = input('Enter a sentence = ').title()
print(str)