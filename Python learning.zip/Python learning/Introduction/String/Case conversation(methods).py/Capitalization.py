str = input('Enter your name =').capitalize()
print(str)