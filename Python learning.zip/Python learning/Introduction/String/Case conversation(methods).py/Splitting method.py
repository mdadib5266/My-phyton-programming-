str = "a,b,c" # a,b,c isnt a single string
print(str.split(",")) # we have to soecfy on what basis we want to split as a string
# it will retirn a list