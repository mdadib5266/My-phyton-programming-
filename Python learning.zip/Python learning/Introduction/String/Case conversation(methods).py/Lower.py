str = "THIS IS STRING"
# format of methods — variable.method()
# Always put first brackts after a method
print(str.lower())
str1 = "THIS IS STRING".lower()
print(str1)
str2 = input('enter your name').lower()#preferable
print(str2)