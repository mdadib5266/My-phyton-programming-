str = input('Enter a sentence = ').swapcase()
print(str)