str = input('enter your name').upper()
print(str)