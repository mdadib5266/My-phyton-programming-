#find(sub string)
text = "python programming"
print(text.find('g'))
# find will find the first occourance index number of the object i passed into the bracket
# it will give the first index number of the object even if there are two objects similar to wach other. it will choose the first object