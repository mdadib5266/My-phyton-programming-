str = "a,b,c"
split = str.split(",")
print('after spliting',split)
#join(iterable)
result = ",".join(split)
print("after joining",result)