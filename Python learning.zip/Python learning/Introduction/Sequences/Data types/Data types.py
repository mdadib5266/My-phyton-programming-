""" Data types 
1 numeric type
  1 int- whole numbers 100 200 -100
  2 float - desimal numbers 1.145 -10.55
  3 complex - real & imaginary part
  a + bj
  3 + 4j
"""
a = 10
b = 10.200
c = 3+ 4j
print(a,b,c,type(c))
#format of type variable ; type(variable)