'''
1 Here data are stored in pairs
2 format is 'key:value'
3 If I have multiple variables than they will be stored like key1:value1,key2:value2.....
4 We will use cirly braces to create dictionery 
5 Values stored in pairs are called dictioneries
'''
person ={
  'name':'gopal','age':100, 'number':872626278,100:100.100
}
# Dont use equal sign to assign values in terms of dictioneries
print(person)