reault = None
result = 100 #can be modified later
print(result)