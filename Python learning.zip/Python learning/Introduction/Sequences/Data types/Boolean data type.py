"""
True/False
logical operations
"""
is_raining = True
is_sunny = False
print(is_raining,is_sunny)