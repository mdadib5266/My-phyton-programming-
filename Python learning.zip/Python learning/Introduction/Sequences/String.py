#Sequence Data type
# Different data can be stored using a single variable
#Types
"""
  1 string #A sequence of charracters which can be expressed under single and double quations ' data' "data"
  #string is immutable= these cant be changed after defined once but can be updated.
  2 list
  3 tuple 
  """
text = " this is a string"
print(text,type(text))
