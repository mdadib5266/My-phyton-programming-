# Group of elements can be stored in a singke veriable
my_list = ['data1','data2','data3']
print(my_list)
#its like a bag containing every type of elements 
# lists are mutable 