# tuple is like list but we use parenthesis instead of third bracket
#tuples are immutable(unmodifiable)
my_tuple = ('data1','data2','data3')
print(my_tuple,type(my_tuple))
