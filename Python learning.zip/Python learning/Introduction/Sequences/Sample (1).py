print('hello world!')
print('text')