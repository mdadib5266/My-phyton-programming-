#Frozenset is immutable
#A box which is sealed. we can see the elements but we cant change them.
# It stores common values
# Its used as a midifier of sets
#Whenever we use frozenset , we have to put an extra parenthesis sround the curlie brackets
immutable_set = frozenset({1,2,3,3,4,4})
print(immutable_set)