'''
Set is mutable.
Sets are group of unique elements.
Frozenset are immutable.
We use curlie/second brackets to express Sets.
Set contains only unique values.
'''
unique_number = {1,2,3,3,3,4,5,5}
#not first or second brackets
print(unique_number,type(unique_number))